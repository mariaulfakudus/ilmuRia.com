<?php

namespace frontend\models;
use common\models\User as User1;


class User extends User1{
	
}
?>
